package it.ricky.servertesttools;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public final class ServerTestToolsClient implements ClientModInitializer {
    public static boolean showCoordinates = true;
    public static boolean showFps = true;
    public static boolean showLocalChunk = false;

    @Override
    public void onInitializeClient() {
        class_304 menuKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.servertesttools.open_menu",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_SPACE,
                class_304.class_11900.field_62556
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.method_1436()) {
                if (client.field_1690.field_1832.method_1434() && client.field_1755 == null) {
                    client.method_1507(new DiagnosticsScreen(null));
                }
            }
        });

        HudRenderCallback.EVENT.register((context, tickCounter) -> renderHud(class_310.method_1551(), context));
    }

    private static void renderHud(class_310 client, class_332 context) {
        if (client.field_1724 == null || client.field_1687 == null) {
            return;
        }

        int y = 8;
        if (showCoordinates) {
            String coordinates = String.format("XYZ: %d %d %d",
                    client.field_1724.method_31477(), client.field_1724.method_31478(), client.field_1724.method_31479());
                context.method_27535(client.field_1772, class_2561.method_43470(coordinates), 8, y, 0xFFFFFF);
            y += 12;
        }
        if (showFps) {
                context.method_27535(client.field_1772, class_2561.method_43470("FPS: " + client.method_47599()), 8, y, 0xFFFFFF);
            y += 12;
        }
        if (showLocalChunk) {
            int chunkX = client.field_1724.method_31477() >> 4;
            int chunkZ = client.field_1724.method_31479() >> 4;
                context.method_27535(client.field_1772,
                    class_2561.method_43470("Current chunk: " + chunkX + ", " + chunkZ), 8, y, 0xFFFFFF);
        }
    }
}
